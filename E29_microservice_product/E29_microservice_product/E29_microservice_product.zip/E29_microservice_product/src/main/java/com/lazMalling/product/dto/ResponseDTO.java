package com.lazMalling.product.dto;
import lombok.Data;

@Data
public class ResponseDTO {
    private ProductDTO productDto;
    private UserDTO UserDto;

}
